[VMware.VimAutomation.Sdk.Interop.V1.CoreServiceFactory]::CoreService.OnImportModule(
    "VMware.DeployAutomation",
    (Split-Path $script:MyInvocation.MyCommand.Path));

#set aliases
set-alias Apply-ESXImageProfile Set-ESXImageProfileAssociation -Scope Global

function global:Get-AutoDeployCommand([string] $Name = "*") {
  get-command -module VMware.DeployAutomation -Name $Name
}

set-alias Get-DeployCommand Get-AutoDeployCommand -Scope Global

# .SYNOPSIS
# Set the value used to logically link an ESXi host in vCenter to a physical machine.
#
# .DESCRIPTION
# The Set-DeployMachineIdentity function is used to logically link an ESXi host in vCenter to a physical machine that will be booted with AutoDeploy.  Typically, AutoDeploy will keep track of the mapping between physical hosts and the hosts in vCenter.  However, if the host was added to vCenter through other means, such as a disconnected add, then this function needs to be used to tell AutoDeploy about the mapping.
#
# The function takes two arguments, the host in vCenter and a string describing the machine identifier to use.  The supported machine identifiers are the BIOS UUID and the MAC address of the network interface card that will be used to boot the machine.  An automated way to retrieve machine identifiers is by listening for the "pxeBootNoImageRule" event that is sent by AutoDeploy when a machine tries to network boot and there are no matching image rules.
#
# Detail: The implementation is done using a custom attribute on the host in vCenter.  This cmdlet and the getter are just powershell functions that call the existing PowerCLI cmdlets for manipulating custom attributes.
#
# .PARAMETER VMHost
# The VMHost object or name of the host in vCenter that the identifier should be associated with.
#
# .PARAMETER Identifier
# A string of the form "<type>=<value>" where the identifier types are "uuid" and "mac".   The "uuid" type corresponds to the machine's BIOS UUID and the "mac" type corresponds to the MAC address of the network interface card that will be used to network boot.
#
# .EXAMPLE
# C:\PS> Set-DeployMachineIdentity -VMHost (Get-VMHost h1) -Identifier "uuid=d5adcb43-fe5e-4034-9fa3-fd5afac1e0f1"
#
# Associate the host in vCenter named "h1" with the physical machine that has the BIOS UUID "d5adcb43-fe5e-4034-9fa3-fd5afac1e0f1".
#
# .LINK
# Get-DeployMachineIdentity
#
function global:Set-DeployMachineIdentity($VMHost, $Identifier)
{
    $identAttribute = Get-CustomAttribute -Name "AutoDeploy.MachineIdentity"
    if ($identAttribute)
    {
        if (! ($Identifier -match "^(uuid=[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}|mac=[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2})") )
        {
            throw "Identifier is bad"
        }
        else
        {
            $anno = Set-Annotation -CustomAttribute $identAttribute -Entity $VMHost -Value $Identifier
            if(!$anno)
            {
                throw "Set-Annotation call failed"
            }
        }
    }
    else
    {
        throw "Cannot find AutoDeploy machine identity custom attribute"
    }
}

#
# .SYNOPSIS
# Return a string value that AutoDeploy uses to identify a particular physical machine
#
# .DESCRIPTION
# Get the machine identifier used to logically link an ESXi host in vCenter to a physical machine.  AutoDeploy can use this mapping for hosts that are manually added to vCenter by the user.  The value will not be set for hosts automatically added by AutoDeploy.
#
# See the help for Set-DeployMachineIdentity for more details.
#
# .PARAMETER VMHost
# The VMHost object or name of the host in vCenter that the identifier should be associated with.
#
# .EXAMPLE
# C:\PS> Get-DeployMachineIdentity -VMHost (Get-VMHost h1)
#
# .LINK
# Set-DeployMachineIdentity
#
function global:Get-DeployMachineIdentity($VMHost)
{
    $identAttribute = Get-CustomAttribute -Name "AutoDeploy.MachineIdentity"
    if ($identAttribute)
    {
        $anno = Get-Annotation -CustomAttribute $identAttribute -Entity $VMHost
        if(!$anno)
        {
            throw "Get-Annotation call failed"
        }
        return $anno.Value
    }
    else
    {
        throw "Cannot find AutoDeploy machine identity custom attribute"
    }
}

# SIG # Begin signature block
# MIIdVgYJKoZIhvcNAQcCoIIdRzCCHUMCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUk5sUo9nZGlbbXJO1qeQ1pGXw
# XAKgghhpMIID7jCCA1egAwIBAgIQfpPr+3zGTlnqS5p31Ab8OzANBgkqhkiG9w0B
# AQUFADCBizELMAkGA1UEBhMCWkExFTATBgNVBAgTDFdlc3Rlcm4gQ2FwZTEUMBIG
# A1UEBxMLRHVyYmFudmlsbGUxDzANBgNVBAoTBlRoYXd0ZTEdMBsGA1UECxMUVGhh
# d3RlIENlcnRpZmljYXRpb24xHzAdBgNVBAMTFlRoYXd0ZSBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTIxMjIxMDAwMDAwWhcNMjAxMjMwMjM1OTU5WjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMjCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALGss0lUS5ccEgrYJXmRIlcqb9y4JsRDc2vCvy5Q
# WvsUwnaOQwElQ7Sh4kX06Ld7w3TMIte0lAAC903tv7S3RCRrzV9FO9FEzkMScxeC
# i2m0K8uZHqxyGyZNcR+xMd37UWECU6aq9UksBXhFpS+JzueZ5/6M4lc/PcaS3Er4
# ezPkeQr78HWIQZz/xQNRmarXbJ+TaYdlKYOFwmAUxMjJOxTawIHwHw103pIiq8r3
# +3R8J+b3Sht/p8OeLa6K6qbmqicWfWH3mHERvOJQoUvlXfrlDqcsn6plINPYlujI
# fKVOSET/GeJEB5IL12iEgF1qeGRFzWBGflTBE3zFefHJwXECAwEAAaOB+jCB9zAd
# BgNVHQ4EFgQUX5r1blzMzHSa1N197z/b7EyALt0wMgYIKwYBBQUHAQEEJjAkMCIG
# CCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3dGUuY29tMBIGA1UdEwEB/wQIMAYB
# Af8CAQAwPwYDVR0fBDgwNjA0oDKgMIYuaHR0cDovL2NybC50aGF3dGUuY29tL1Ro
# YXd0ZVRpbWVzdGFtcGluZ0NBLmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCAQYwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0y
# MDQ4LTEwDQYJKoZIhvcNAQEFBQADgYEAAwmbj3nvf1kwqu9otfrjCR27T4IGXTdf
# plKfFo3qHJIJRG71betYfDDo+WmNI3MLEm9Hqa45EfgqsZuwGsOO61mWAK3ODE2y
# 0DGmCFwqevzieh1XTKhlGOl5QGIllm7HxzdqgyEIjkHq3dlXPx13SYcqFgZepjhq
# IhKjURmDfrYwggSjMIIDi6ADAgECAhAOz/Q4yP6/NW4E2GqYGxpQMA0GCSqGSIb3
# DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMB4XDTEyMTAxODAwMDAwMFoXDTIwMTIyOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTQwMgYDVQQDEytT
# eW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIFNpZ25lciAtIEc0MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAomMLOUS4uyOnREm7Dv+h8GEKU5Ow
# mNutLA9KxW7/hjxTVQ8VzgQ/K/2plpbZvmF5C1vJTIZ25eBDSyKV7sIrQ8Gf2Gi0
# jkBP7oU4uRHFI/JkWPAVMm9OV6GuiKQC1yoezUvh3WPVF4kyW7BemVqonShQDhfu
# ltthO0VRHc8SVguSR/yrrvZmPUescHLnkudfzRC5xINklBm9JYDh6NIipdC6Anqh
# d5NbZcPuF3S8QYYq3AhMjJKMkS2ed0QfaNaodHfbDlsyi1aLM73ZY8hJnTrFxeoz
# C9Lxoxv0i77Zs1eLO94Ep3oisiSuLsdwxb5OgyYI+wu9qU+ZCOEQKHKqzQIDAQAB
# o4IBVzCCAVMwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAO
# BgNVHQ8BAf8EBAMCB4AwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5odHRw
# Oi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6Ly90
# cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwPAYDVR0fBDUwMzAx
# oC+gLYYraHR0cDovL3RzLWNybC53cy5zeW1hbnRlYy5jb20vdHNzLWNhLWcyLmNy
# bDAoBgNVHREEITAfpB0wGzEZMBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMjAdBgNV
# HQ4EFgQURsZpow5KFB7VTNpSYxc/Xja8DeYwHwYDVR0jBBgwFoAUX5r1blzMzHSa
# 1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBAHg7tJEqAEzwj2IwN3ijhCcH
# bxiy3iXcoNSUA6qGTiWfmkADHN3O43nLIWgG2rYytG2/9CwmYzPkSWRtDebDZw73
# BaQ1bHyJFsbpst+y6d0gxnEPzZV03LZc3r03H0N45ni1zSgEIKOq8UvEiCmRDoDR
# EfzdXHZuT14ORUZBbg2w6jiasTraCXEQ/Bx5tIB7rGn0/Zy2DBYr8X9bCT2bW+IW
# yhOBbQAuOA2oKY8s4bL0WqkBrxWcLC9JG9siu8P+eJRRw4axgohd8D20UaF5Mysu
# e7ncIAkTcetqGVvP6KUwVyyJST+5z3/Jvz4iaGNTmr1pdKzFHTx/kuDDvBzYBHUw
# ggTRMIIDuaADAgECAhBlO8IY/xbhmnONwPCxJt5hMA0GCSqGSIb3DQEBCwUAMH8x
# CzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0G
# A1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazEwMC4GA1UEAxMnU3ltYW50ZWMg
# Q2xhc3MgMyBTSEEyNTYgQ29kZSBTaWduaW5nIENBMB4XDTE1MDcyNDAwMDAwMFoX
# DTE4MDgyMjIzNTk1OVowZDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCkNhbGlmb3Ju
# aWExEjAQBgNVBAcTCVBhbG8gQWx0bzEVMBMGA1UEChQMVk13YXJlLCBJbmMuMRUw
# EwYDVQQDFAxWTXdhcmUsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQDCmS07ZAwM9eVLBDfxw1rKIge6PZwfP8Xh2YSsyjzRUzzBouY4j7GTjM2e
# OZLiZhL+B32ps1BdfKJfSBaOein4ynaxVgCf9XuVWQKIZMzss+FJcf5gOk0dV/9t
# CHzIfoC81H1/PrnkX0uXRHcuz22m9FH9ggA3CLJPQlumTcxtqftNFSJsX0BT3Afg
# VDs/lsCEeY8VodT9AJzGGVGMz0YIB2J0gM8w9s9/1znjh4BFRp2AfrBk2Y0Ujoh2
# gaZEoLMfX1mI+QJdsKRNRt+lBerbyH93DupYJPviUavYiEg/b3+4xsYmkjq7dcNc
# ZTB93URHdg6ipSo3/R6B4PzUow5fAgMBAAGjggFiMIIBXjAJBgNVHRMEAjAAMA4G
# A1UdDwEB/wQEAwIHgDArBgNVHR8EJDAiMCCgHqAchhpodHRwOi8vc3Yuc3ltY2Iu
# Y29tL3N2LmNybDBmBgNVHSAEXzBdMFsGC2CGSAGG+EUBBxcDMEwwIwYIKwYBBQUH
# AgEWF2h0dHBzOi8vZC5zeW1jYi5jb20vY3BzMCUGCCsGAQUFBwICMBkMF2h0dHBz
# Oi8vZC5zeW1jYi5jb20vcnBhMBMGA1UdJQQMMAoGCCsGAQUFBwMDMFcGCCsGAQUF
# BwEBBEswSTAfBggrBgEFBQcwAYYTaHR0cDovL3N2LnN5bWNkLmNvbTAmBggrBgEF
# BQcwAoYaaHR0cDovL3N2LnN5bWNiLmNvbS9zdi5jcnQwHwYDVR0jBBgwFoAUljtT
# 8Hkzl699g+8uK8zKt4YecmYwHQYDVR0OBBYEFGaw3m9kanGu85olA8OJIdV3JXR/
# MA0GCSqGSIb3DQEBCwUAA4IBAQA27zm4ThfMqwr7AVYhk6efINp10t4N+ip4DxqQ
# t8Z+SSnPUeO23MmoUHFVWhJS57lgx0FVdAcUBdSmh/N7YvtoGfTOr4Q6k6Z6bjmV
# hUD3QIL77lGPGeotS8QIPeb9F5lX4Y/eiwRZ8254MFM0D2r+CgSVs123MS0zEZjF
# r7ychqVu77UXEuaQFDHkS1fEsiaRqrEnu8pNhcFVwZCzLJnn9DYOfpfgG8s8pwCF
# 2J6Cxs5MFPiO35OfZuXqRRx/7wlCIj6rcyb4sq62ksRA1On8OP6svY6AucSzTTFI
# SYrHImOnHnffhNrBogdf5uuwEuom3KoKMOt/0QqAXDt4cO9fMIIFWTCCBEGgAwIB
# AgIQPXjX+XZJYLJhffTwHsqGKjANBgkqhkiG9w0BAQsFADCByjELMAkGA1UEBhMC
# VVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZWZXJpU2lnbiBU
# cnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJpU2lnbiwgSW5jLiAt
# IEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxWZXJpU2lnbiBDbGFz
# cyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0aG9yaXR5IC0gRzUw
# HhcNMTMxMjEwMDAwMDAwWhcNMjMxMjA5MjM1OTU5WjB/MQswCQYDVQQGEwJVUzEd
# MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVj
# IFRydXN0IE5ldHdvcmsxMDAuBgNVBAMTJ1N5bWFudGVjIENsYXNzIDMgU0hBMjU2
# IENvZGUgU2lnbmluZyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB
# AJeDHgAWryyx0gjE12iTUWAecfbiR7TbWE0jYmq0v1obUfejDRh3aLvYNqsvIVDa
# nvPnXydOC8KXyAlwk6naXA1OpA2RoLTsFM6RclQuzqPbROlSGz9BPMpK5KrA6Dmr
# U8wh0MzPf5vmwsxYaoIV7j02zxzFlwckjvF7vjEtPW7ctZlCn0thlV8ccO4XfduL
# 5WGJeMdoG68ReBqYrsRVR1PZszLWoQ5GQMWXkorRU6eZW4U1V9Pqk2JhIArHMHck
# EU1ig7a6e2iCMe5lyt/51Y2yNdyMK29qclxghJzyDJRewFZSAEjM0/ilfd4v1xPk
# OKiE1Ua4E4bCG53qWjjdm9sCAwEAAaOCAYMwggF/MC8GCCsGAQUFBwEBBCMwITAf
# BggrBgEFBQcwAYYTaHR0cDovL3MyLnN5bWNiLmNvbTASBgNVHRMBAf8ECDAGAQH/
# AgEAMGwGA1UdIARlMGMwYQYLYIZIAYb4RQEHFwMwUjAmBggrBgEFBQcCARYaaHR0
# cDovL3d3dy5zeW1hdXRoLmNvbS9jcHMwKAYIKwYBBQUHAgIwHBoaaHR0cDovL3d3
# dy5zeW1hdXRoLmNvbS9ycGEwMAYDVR0fBCkwJzAloCOgIYYfaHR0cDovL3MxLnN5
# bWNiLmNvbS9wY2EzLWc1LmNybDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUH
# AwMwDgYDVR0PAQH/BAQDAgEGMCkGA1UdEQQiMCCkHjAcMRowGAYDVQQDExFTeW1h
# bnRlY1BLSS0xLTU2NzAdBgNVHQ4EFgQUljtT8Hkzl699g+8uK8zKt4YecmYwHwYD
# VR0jBBgwFoAUf9Nlp8Ld7LvwMAnzQzn6Aq8zMTMwDQYJKoZIhvcNAQELBQADggEB
# ABOFGh5pqTf3oL2kr34dYVP+nYxeDKZ1HngXI9397BoDVTn7cZXHZVqnjjDSRFph
# 23Bv2iEFwi5zuknx0ZP+XcnNXgPgiZ4/dB7X9ziLqdbPuzUvM1ioklbRyE07guZ5
# hBb8KLCxR/Mdoj7uh9mmf6RWpT+thC4p3ny8qKqjPQQB6rqTog5QIikXTIfkOhFf
# 1qQliZsFay+0yQFMJ3sLrBkFIqBgFT/ayftNTI/7cmd3/SeUx7o1DohJ/o39KK9K
# Er0Ns5cF3kQMFfo2KwPcwVAB8aERXRTl4r0nS1S+K4ReD6bDdAUK75fDiSKxH3fz
# vc1D1PFMqT+1i4SvZPLQFCEwggWaMIIDgqADAgECAgphGZPkAAAAAAAcMA0GCSqG
# SIb3DQEBBQUAMH8xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# KTAnBgNVBAMTIE1pY3Jvc29mdCBDb2RlIFZlcmlmaWNhdGlvbiBSb290MB4XDTEx
# MDIyMjE5MjUxN1oXDTIxMDIyMjE5MzUxN1owgcoxCzAJBgNVBAYTAlVTMRcwFQYD
# VQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0
# d29yazE6MDgGA1UECxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0
# aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVyaVNpZ24gQ2xhc3MgMyBQdWJs
# aWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAryQICCl6NZ5gDKrnSztO3Hy8PEUcuyvg
# /ikC+VcIo2SFFSf18a3IMYldIugqqqZCs4/4uVW3sbdLs/6PfgdX7O9D22ZiFWHP
# YA2k2N744MNiCD1UE+tJyllUhSblK48bn+v1oZHCM0nYQ2NqUkvSj+hwUU3RiWl7
# x3D2s9wSdNt7XUtW05a/FXehsPSiJfKvHJJnGOX0BgTvkLnkAOTdOrUZ/wK69Dzu
# 4IvrN4vs9Nes8vbwPa/ddZEzGR0cQMt0JBkhk9kU/qwqUseP1QRJ5I1jR4g8aYPL
# /ke9K35PxZWuDp3U0UPAZ3PjFAh+5T+fc7gzCs9dPzSHloruU+glFQIDAQABo4HL
# MIHIMBEGA1UdIAQKMAgwBgYEVR0gADAPBgNVHRMBAf8EBTADAQH/MAsGA1UdDwQE
# AwIBhjAdBgNVHQ4EFgQUf9Nlp8Ld7LvwMAnzQzn6Aq8zMTMwHwYDVR0jBBgwFoAU
# YvsKIVt/Q24R2glUUGv10pZx8Z4wVQYDVR0fBE4wTDBKoEigRoZEaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljcm9zb2Z0Q29kZVZl
# cmlmUm9vdC5jcmwwDQYJKoZIhvcNAQEFBQADggIBAIEqghaMNGcr5QPrNHuMoqNQ
# ivRVhvEejI6ufe4DGc5ylRhIrWIR/SD9P0cGAVri4G+MFSxOPGpQbAs2o896DZxC
# vFz4GdVg42nm4iNBZ4xog3Yrj5OjKrV/vln7qcmyJo/KovOCG5g+kZUnl4Zh7ltd
# B2vNhqjiZYCo4hXisr4jBWq6DPNHk02spIwHeTnAYRI6BQ2Jo+yfV4mE++zKfEdm
# FJHYtg8ZXea4Sqy8R8hxQ5bmMiCl3HeG/Tzji3Hbe5sD/LcdMmTrFlKgQ6P6Lq1Z
# kk58x/IzQkg4UTp8OMcbJCIoQB4aRh8X2xj38Cc1bLhj2c25ZF0rpV7vxim08sf4
# IcwEulf9Abarxmf559OZf/T1Ivpy9f3/OhxCOqH5gBil7o0c1GaeRQH+qu7/+xeP
# MPfxzSnFney11UkAPYW4y7uTOidqScAwrmbJ9yMoMnb5pINWyEjOWpaqoMwMxH+0
# jpevbeNUJ8OfhsDW5HMIlwXb0FRiXgNIwtWff6dmjNCdsE/U05hfS3rJf7IpUtAS
# gMcPVLYeZ83GoGwRA4TTSHXnKv6wO24KOqZrdpkFo/F3aGEzFEcG/FN/Ur2SFFxK
# JGpnjK+NkKrQ9nkhG5MmfMPOHr2IOJKuRcYZaklQswX4rlk3imolA5SxWYFQ6LqD
# gLcjNfR2uWcdWRitII2UMYIEVzCCBFMCAQEwgZMwfzELMAkGA1UEBhMCVVMxHTAb
# BgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1hbnRlYyBU
# cnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBDbGFzcyAzIFNIQTI1NiBD
# b2RlIFNpZ25pbmcgQ0ECEGU7whj/FuGac43A8LEm3mEwCQYFKw4DAhoFAKCBijAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUUVUEJTwW9W9Kqj1zOcef+KqNAdIwKgYK
# KwYBBAGCNwIBDDEcMBqhGIAWaHR0cDovL3d3dy52bXdhcmUuY29tLzANBgkqhkiG
# 9w0BAQEFAASCAQCoasPoJvkg7jxa6kmnLVk0+RC37W1nIifrgeFXz7gLVvRSvzAb
# O91OckxJY2fM7BsM+sa6E5d9H6Yqj9K0Hq1kcLxCTo1Fvr7mlBKzxenISizZ4klG
# Lxbv3WdKNBcWfLx9Cs+HKVFst40nVZkvAUt/W4uBsmLkSLiNxPUNsIKRvks51n6J
# 2S8xxrKU249R1hsiqxT5vw8Heuv8xQBw0z55fcoIC6QZV4QYBS+t72Apx6rvKUKK
# 7Hj08ILZXxwkhnRuPaSgfRb8vwJEAZB+My2jK9a6OulneWKKAMpoUQjq0VoZG/+6
# pldCLi0bHUPJ4NV5gffCvLBXz5wVSb3ixJPUoYICCzCCAgcGCSqGSIb3DQEJBjGC
# AfgwggH0AgEBMHIwXjELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENv
# cnBvcmF0aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZp
# Y2VzIENBIC0gRzICEA7P9DjI/r81bgTYapgbGlAwCQYFKw4DAhoFAKBdMBgGCSqG
# SIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE4MDQxMjIxMTM0
# N1owIwYJKoZIhvcNAQkEMRYEFGwi7sB2Y+r3ls/Ka+bGdl+omCvzMA0GCSqGSIb3
# DQEBAQUABIIBAJgwyhiaJahACciiJiar7vOQgDVGJs4t9TWirxNxhDOzuTjOhXRG
# 5iDDHeQUJ5dOJv9IeFrXcKhEX0mp3VxbCvK+AkY5CCqaTkCixZJ1m75OOu+qx7ep
# RqsHmjLTOcBsM7kSvWlhSTJIKH8zq27VORU83kX4kAa5cL1URYBshnq5l4Z/N/R8
# vJ54fkwLdmJx6K32/KOvvT58I2WHLFwc577pQj8W3mvJvymfTwf1eKpClLhxZDXa
# opovIE502ZoAer5RB++Qzn4UCu+8Q/T+MESIcAVQL83wTVPX3PZPhEzBsqLSFWMz
# DdJcsfgJG2C6UOagWxXBalCAJ4+oAeWBTYM=
# SIG # End signature block
